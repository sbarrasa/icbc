package com.ebanking.utils.validate;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class CompositeValidator<T> extends AbstractValidator<T> implements CustomValidable<T> {
  private T object = null;
  private Predicate<T> condition = t -> true;
  private String exceptionMessage = "%s no es válido";
  private Function<T, ? extends Exception> exceptionFunction = o -> new Exception(exceptionMessage.formatted(o));
  public T getObject() {return object;}

  @Override
  public Predicate<T> getCondition() {return this.condition;}

  @Override
  public Function<T, ? extends Exception> getExceptionFunction() {
    return this.exceptionFunction;
  }

  @Override
  public String getExceptionMessage() {
    return this.exceptionMessage ;
  }

  private final List<Validable<T>> validables = new ArrayList<>();

  public CompositeValidator() {}

  public CompositeValidator(T object) {
    setObject(object);
  }

  public CompositeValidator<T> add(Validable<T> validable) {
    validables.add(validable);
    if (validable instanceof CustomValidable<T> customValidable) {
      customValidable.setObject(this.getObject());
      customValidable.setCondition(this.getCondition());
      customValidable.setExceptionFunction(this.getExceptionFunction());
      customValidable.setExceptionMessage(this.getExceptionMessage());
    }
    return this;
  }

  @Override
  public CustomValidable<T> setObject(T object) {
    this.object = object;
    customValidables().forEach(v -> v.setObject(object));
    return this;
  }

  @Override
  public CustomValidable<T> setCondition(Predicate<T> condition) {
    this.condition = condition;
    customValidables().forEach(v -> v.setCondition(condition));
    return this;
  }

  @Override
  public CustomValidable<T> setExceptionFunction(Function<T, ? extends Exception> exceptionFunction) {
    this.exceptionFunction = exceptionFunction;
    customValidables().forEach(v -> v.setExceptionFunction(exceptionFunction));
    return this;
  }

  @Override
  public CustomValidable<T> setExceptionMessage(String message) {
    this.exceptionMessage = exceptionMessage;
    customValidables().forEach(v -> v.setExceptionMessage(message));
    return this;
  }


  public List<Validable<T>> validables() {
    return validables;
  }

  public List<CustomValidable<T>> customValidables() {
    return validables.stream()
            .filter(v -> v instanceof CustomValidable<T>)
            .map(v -> (CustomValidable<T>) v)
            .toList();
  }

  @Override
  public void validate() throws Exception {
    for (Validable<T> validator : validables) {
      validator.validate();
    }
  }
}


