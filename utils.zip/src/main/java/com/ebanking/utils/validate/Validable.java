package com.ebanking.utils.validate;

public interface Validable<T> {
  void validate() throws Exception;
}