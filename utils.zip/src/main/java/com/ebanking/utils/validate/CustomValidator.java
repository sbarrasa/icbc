package com.ebanking.utils.validate;

import java.util.function.Function;
import java.util.function.Predicate;

public class CustomValidator<T> extends AbstractValidator<T> implements CustomValidable<T> {

  private T object = null;
  private Predicate<T> condition = t -> true;
  private String exceptionMessage = "%s inválido";
  private Function<T, ? extends Exception> exceptionFunction = o -> new Exception(exceptionMessage.formatted(o));
  public T getObject() {return object;}

  @Override
  public Predicate<T> getCondition() {
    return this.condition;
  }

  @Override
  public Function<T, ? extends Exception> getExceptionFunction() {
    return this.exceptionFunction;
  }

  @Override
  public String getExceptionMessage() {
    return this.exceptionMessage;
  }

  public CustomValidator() {}

  public CustomValidator(T object) {this.setObject(object);}

  @Override
  public CustomValidable<T> setObject(T object) {
    this.object = object;
    return this;
  }

  @Override
  public CustomValidable<T> setCondition(Predicate<T> condition) {
    this.condition = condition;
    return this;
  }

  @Override
  public CustomValidable<T> setExceptionFunction(Function<T, ? extends Exception> exceptionFunction) {
    this.exceptionFunction = exceptionFunction;
    return this;
  }

  @Override
  public CustomValidable<T> setExceptionMessage(String message) {
    this.exceptionMessage = message;
    return this;
  }

  @Override
  public final void validate() throws Exception{
    super.validate();
  }
}