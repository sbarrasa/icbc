package com.ebanking.utils.validate;

import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public interface CustomValidable<T> extends Validable<T> {
  CustomValidable<T> setObject(T object);
  CustomValidable<T> setCondition(Predicate<T> condition);

  default CustomValidable<T> setExceptionSuplier(Supplier<? extends Exception> exceptionSupplier) {
    return setExceptionFunction(t -> exceptionSupplier.get());
  }

  CustomValidable<T> setExceptionFunction(Function<T, ? extends Exception> exceptionFunction);
  CustomValidable<T> setExceptionMessage(String message);
}
