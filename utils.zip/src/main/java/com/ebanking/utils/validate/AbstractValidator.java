package com.ebanking.utils.validate;

import java.util.function.Function;
import java.util.function.Predicate;

public abstract class AbstractValidator<T> implements Validable<T> {
  public abstract T getObject();
  public abstract Predicate<T> getCondition();
  public abstract Function<T, ? extends Exception> getExceptionFunction();


  public abstract String getExceptionMessage();

  @Override
  public void validate() throws Exception{
    if (!getCondition().test(getObject())) {
      throw getExceptionFunction().apply(getObject());
    }

  }


}
