package com.ebanking.utils.safequery;

import com.ebanking.utils.validate.CustomValidable;
import com.ebanking.utils.validate.Validable;

import java.util.function.Function;

public class SafeQuery<RQ, RS> implements Validable<RS> {
  private CustomValidable<RS> validator;
  private Function<RQ, RS> commandSuplier = (rq) -> { return null;};


  public RS get(RQ request){
    RS response = commandSuplier.apply(request);
    validator.setObject(response);
    return response;
  }

  public RS getValid(RQ request) throws Exception {
    RS response = get(request);
    validate();
    return response;
  }

  @Override
  public void validate() throws Exception {
    validator.validate();
  }


  public SafeQuery<RQ, RS> setValidator(CustomValidable<RS> validator) {
    this.validator = validator;
    return this;
  }

  public SafeQuery<RQ, RS> setCommand(Function<RQ, RS> commandSuplier){
    this.commandSuplier = commandSuplier;
    return this;
  }

}
