package com.ebanking.utils.safequery;

import com.ebanking.utils.validate.CustomValidator;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

class SafeQueryTest {
  private static String getValue(Integer i){
    return data.get(i);
  }
  private static Map<Integer, String> data;

  private SafeQuery<Integer, String> safeQuery;

  @BeforeAll
  static void initAll(){
     data = Map.of(
            1, "Hola",
            2, "Chau",
            3, "");

  }


  @BeforeEach
  void init(){
    safeQuery = new SafeQuery<Integer, String>()
            .setCommand(data::get)
            .setValidator(new CustomValidator<String>()
                    .setCondition(s -> !s.isEmpty()));

  }

  @Test
  void get() {
    var response = safeQuery.get(1);
    assertEquals("Hola", response);
   }

  @Test
  void getValidOk() throws Exception {

    assertEquals("Hola", safeQuery.getValid(1));

  }

  @Test
  void getValidErr() throws Exception {
    assertThrows(Exception.class, () -> safeQuery.getValid(3));
  }

  @Test
  void validateOk() {
    var response = safeQuery.get(1);
    assertDoesNotThrow(safeQuery::validate);
  }

  @Test
  void validateErr() {
    var response = safeQuery.get(3);
    assertThrows(Exception.class, safeQuery::validate);
  }

  @Test
  void getValidStatic() throws Exception {
    var staticClient = new SafeQuery<Integer, String>()
            .setCommand(SafeQueryTest::getValue)
            .setValidator(new CustomValidator<String>()
                    .setCondition(rs -> !rs.isEmpty()));

    assertEquals("Hola", staticClient.getValid(1));
    assertThrows(Exception.class, () -> staticClient.getValid(3));
  }


}