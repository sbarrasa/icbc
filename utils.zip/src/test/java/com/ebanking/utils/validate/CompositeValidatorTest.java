package com.ebanking.utils.validate;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CompositeValidatorTest {

  @Test
  void validate() {
    String testStr = "Hola mundo";
    var compositValidator = new CompositeValidator<String>()
            .add(new OtherValidator("Pepe"))
            .add(new TestValidator("Pipo"))
            .add(new CompositeValidator<>(testStr).setExceptionMessage("Un mensaje"));

    assertThrows(Exception.class, compositValidator::validate);
  }
}