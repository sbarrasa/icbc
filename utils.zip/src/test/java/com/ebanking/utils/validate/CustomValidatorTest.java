package com.ebanking.utils.validate;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CustomValidatorTest {
  static CustomValidator<String> customValidator = new CustomValidator<>();

  @BeforeAll
  static void init(){
    String teststr = "Hola mundo";
    customValidator
            .setObject(teststr)
            .setExceptionFunction(o -> new RuntimeException("La palabra %s es incorrecta".formatted(o)));

  }

  @Test
  void validateSimpleWithConstructor() {
    var simpleValidator = new CustomValidator<>("Hola");
    assertDoesNotThrow(simpleValidator::validate);
  }

  @Test
  void validateSimple() {
    var simpleValidator = new CustomValidator<>();
    assertDoesNotThrow(simpleValidator::validate);
  }

  @Test
  void validateOk() {

    customValidator.setCondition(o -> o.substring(0,1).equals("H"));
    assertDoesNotThrow(customValidator::validate);

  }

  @Test
  void validateErr() {
    customValidator.setCondition(o -> o.substring(0,1).equals("J"));
    var ex = assertThrows(RuntimeException.class, customValidator::validate);
    assertEquals("La palabra", ex.getMessage().substring(0,10));

  }

}