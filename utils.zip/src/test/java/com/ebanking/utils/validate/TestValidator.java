package com.ebanking.utils.validate;

import java.util.function.Function;
import java.util.function.Predicate;

public class TestValidator extends AbstractValidator<String> {
  final String testStr;
  public TestValidator(String testStr) {
    this.testStr = testStr;
  }

  @Override
  public String  getObject() {
    return testStr;
  }

  @Override
  public Predicate<String> getCondition() {
    return o -> o.contains("Hola");
  }

  @Override
  public Function<String, ? extends Exception> getExceptionFunction() {
    return o -> new RuntimeException(getExceptionMessage().formatted(o));
  }

  @Override
  public String getExceptionMessage() {
    return "%s es la palabra que usted puso";
  }
}