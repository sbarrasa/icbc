package com.ebanking.utils.validate;

public class OtherValidator implements Validable<String>{
  private final String value;

  public OtherValidator(String value){
    this.value = value;
  }
  @Override
  public void validate() throws Exception {
    if(value.equals("Hola mundo")) throw new RuntimeException("Al mundo no hay que saludarlo");
  }
}
