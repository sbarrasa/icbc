package com.ebanking.utils.validate;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AbstractValidatorTest {

  @Test
  void validate() {
    String testStr = "Chau mundo";

    var testValidator = new TestValidator(testStr);


    var ex = assertThrows(RuntimeException.class, testValidator::validate);
    assertTrue(!ex.getMessage().contains("Hola"));

  }
}