package com.ebanking.utils.validate;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;

public class ValidableTest {
  @Test
  void validate(){
    var validable = new OtherValidator("Hola mundo");
    assertThrows(RuntimeException.class, validable::validate);
  }
}
